package baritone.utils.accessor;

public interface IBitArray {

    int[] toArray();
}
